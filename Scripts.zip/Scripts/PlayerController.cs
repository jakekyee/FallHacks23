using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public GameObject gameManager;
    public int health;
    public float fallSpeed, moveSpeed;
    public float inertia;
    public bool vulnerable = true;
    public bool alive;
    public Animator myAnim;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameManager");
        rb = gameObject.GetComponent<Rigidbody2D>();
        myAnim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (health < 1)
        {
            gameManager.GetComponent<GameManager>().alive = false;
            rb.velocity = new Vector2(0, 0);
            return;
        }
        float moveX = Input.GetAxisRaw("Horizontal");
        if (Input.GetKey(KeyCode.Space))
        {
            myAnim.SetBool("isDropping", true);
            rb.velocity = new Vector2(Mathf.Lerp(rb.velocity.x, moveX * moveSpeed, inertia * Time.deltaTime), -2 * fallSpeed);
            if (transform.position.x < -5 && rb.velocity.x < 0)
            {
                rb.velocity = new Vector2(0, -fallSpeed);
            }
            if (transform.position.x > 5 && rb.velocity.x > 0)
            {
                rb.velocity = new Vector2(0, -fallSpeed);
            }
        }
        else
        {
            myAnim.SetBool("isDropping", false);
            rb.velocity = new Vector2(Mathf.Lerp(rb.velocity.x, moveX * moveSpeed, inertia * Time.deltaTime), -fallSpeed);
            if (transform.position.x < -5 && rb.velocity.x < 0)
            {
                rb.velocity = new Vector2(0, -fallSpeed);
            }
            if (transform.position.x > 5 && rb.velocity.x > 0)
            {
                rb.velocity = new Vector2(0, -fallSpeed);
            }
        }
        if(moveX < 0)
        {
            transform.localScale = new Vector3(Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
        }
        if(moveX > 0)
        {
            transform.localScale = new Vector3(-Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
        }
        gameManager.GetComponent<GameManager>().score += rb.velocity.y * Time.deltaTime * -10;
    }

    public void playerHurt()
    {
        
        if (vulnerable)
        {
            gameObject.GetComponent<AudioSource>().Play();
            health--;
            StartCoroutine(Iframes());
        }
    }

    IEnumerator Iframes()
    {
        gameManager.GetComponent<GameManager>().damageTaken(health);
        vulnerable = false;
        yield return new WaitForSeconds(1.5f);
        vulnerable = true;
    }
}
