using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour
{
    float birdPos;
    Transform birdPoint1, birdPoint2;
    // Start is called before the first frame update
    void Start()
    {
        birdPos = 0;
        birdPoint1 = GameObject.FindGameObjectWithTag("Birdpoint1").transform;
        birdPoint2 = GameObject.FindGameObjectWithTag("Birdpoint2").transform;
        gameObject.GetComponent<AudioSource>().Play();
    }

    // Update is called once per frame
    void Update()
    {
        birdPoint1.position = new Vector2(birdPoint1.position.x, birdPoint1.position.y + 0.5f * Time.deltaTime);
        birdPoint2.position = new Vector2(birdPoint2.position.x, birdPoint1.position.y + 0.5f * Time.deltaTime);
        birdPos += Time.deltaTime * 0.3f;
        if(birdPos >= 1)
        {
            Destroy(gameObject);
        }
        transform.position = Vector3.Lerp(birdPoint1.position, birdPoint2.position, birdPos);
        
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Debug.Log("test");
            other.GetComponent<PlayerController>().playerHurt();
        }
    }
}
