using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Branch : MonoBehaviour
{
    GameObject Player;
    SpriteRenderer sr;
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        sr = gameObject.GetComponent<SpriteRenderer>();
        transform.localScale = new Vector3((Random.Range(8f, 13f) / 10f) * transform.localScale.x, transform.localScale.y, transform.localScale.z);
    }
    void Update()
    {
        
        if(transform.position.y > Player.transform.position.y + 7)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Player")
        {
            Debug.Log("test");
            other.GetComponent<PlayerController>().playerHurt();
        }
    }
}
