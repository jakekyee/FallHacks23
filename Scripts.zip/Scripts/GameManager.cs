using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject[] hearts;
    public Transform Player, branchPoint1, branchPoint2, birdPoint1, birdPoint2, cam;
    public Transform scorePos;
    public float edgeOfMap, branchCooldown, branchTime, birdCooldown, birdTime;
    public float score, scoreTime;
    public GameObject branch, bird;
    public GameObject deathScreen;
    public Text scoreDisplay;
    public bool alive;
    int health;
    // Start is called before the first frame update
    void Start()
    {

        branchTime = branchCooldown + 2;
        birdTime = birdCooldown + 3;
        hearts = GameObject.FindGameObjectsWithTag("Heart");
        Player = GameObject.FindGameObjectWithTag("Player").transform;

        scorePos = Player;
    }

    // Update is called once per frame
    void Update()
    {
        if (!alive)
        {
            deathScreen.SetActive(true);
            return;
        }
        branchTime -= Time.deltaTime;
        if(branchTime <= 0)
        {
            spawnBranch();
            branchTime = branchCooldown;
        }

        birdTime -= Time.deltaTime;
        if (birdTime <= 0)
        {
            spawnBird();
            birdTime = birdCooldown + Random.Range(-5,5);
        }
        scoreDisplay.text = Mathf.RoundToInt(score).ToString();
    }

    void spawnBranch()
    {
        int i = Random.Range(0,2);
        if(i == 0)
        {
            Instantiate(branch, branchPoint1.position, Quaternion.identity);
        }
        else
        {
            Instantiate(branch, branchPoint2.position, Quaternion.Euler(new Vector3(0,180,0)));
        }
    }

    public void damageTaken(int health)
    {
        if(health > 0)
        {
            for (int i = 0; i < hearts.Length; i++)
            {
                if (i >= health)
                {
                    hearts[i].SetActive(false);
                }
            }
        }
        
    }


    void spawnBird()
    {
        birdPoint1.position = new Vector2(birdPoint1.position.x, cam.position.y + Random.Range(0, 4) -8);
        birdPoint2.position = new Vector2(birdPoint2.position.x, cam.position.y + Random.Range(0, 4) -8);
        
        Instantiate(bird, birdPoint1.position, Quaternion.identity);
        
            
    }
}
