using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class discordWebhook : MonoBehaviour
{
    public string Score;
    public string Player;
    public GameObject score;
    public GameObject player;

    string webhook_link = "https://discord.com/api/webhooks/1163936302337642577/efxumlO25cB9rgxKwihSR7xc87nLMH-WyRHhqc0cCJA7QeLS47kO6RDIZjB5HoMzv_ah";

    public void SendMsg()
    {
        Score = Mathf.Floor(GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>().score).ToString();
        Player = GameObject.FindGameObjectWithTag("PlayerName").GetComponent<Text>().text;
        StartCoroutine(SendWebhook(webhook_link, Player + "/" + Score, (success) => 
        {
            if (success)
                Debug.Log("score sent");
        }));
        SceneManager.LoadScene("Title");
    }




    IEnumerator SendWebhook(string link, string score, System.Action<bool> action)
    {
        WWWForm form = new WWWForm();
        form.AddField("content", score);
        using (UnityWebRequest www = UnityWebRequest.Post(link, form))
        {
            yield return www.SendWebRequest();

            if (www.isNetworkError || www.isHttpError)
            {
                Debug.Log(www.error);
                action(false);
            }
            else
                action(true);
        }
    }
}

